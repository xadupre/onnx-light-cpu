// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "onnx_core/runtime/runtime_session.h"
#include "onnx_core/runtime/task_completion.h"
#include "onnx_proto/onnx_verify.h"
#include <atomic>

namespace ONNX_LIGHT_NAMESPACE::core::runtime {

/**
 * Carries graph-declared persistent values between model calls.
 *
 * During a RuntimeSession run:
 * 1. Uses retained values for persistent inputs alongside the current feeds.
 * 2. Executes the session, reusing eligible append buffers or allocating new ones.
 * 3. Validates the outputs and checks cancellation.
 * 4. Publishes selected outputs as the next state only on success.
 *
 * Storage:
 * - Views share tensor data but have separate names and shapes.
 * - In-place append writes only the new region; growth may copy the old prefix.
 * - Failure leaves the previous logical state unchanged.
 *
 * Requirements:
 * - Each binding names a whole input/output pair; the input has at least one value-use.
 * - Current feeds cannot replace persistent inputs.
 * - Supports tensors, typed sequences, named structures and inline encoded values.
 * - Tensor leaves may use dense storage or inline affine encoding of the declared logical type.
 * - Shared payloads are read-only; only immutable initializer views may borrow ownerless storage.
 * - The model stays immutable. All calls use the same allocators, kept alive by the caller.
 */
class ONNX_LIGHT_CORE_API PersistentValueState {
public:
  /**
   * Initializes retained values from the graph's persistent bindings.
   *
   * Accepts std::move(initial) to avoid copying owned payloads.
   * The caller keeps the model alive through the state and exported initializer views.
   */
  PersistentValueState(const ModelProto &model, RuntimeValueMap initial,
                       RuntimeSessionOptions options = {});
  /** Replaces retained values with explicitly transferred initial contents. */
  void Reset(RuntimeValueMap initial);
  /** Returns read-only aliases keyed by exact retained graph input names. */
  RuntimeValueMap Values() const;
  /** Returns the immutable model. */
  const ModelProto &model() const { return model_; }
  /** Returns the validated catalogue. */
  const StructTypeCatalogue &struct_type_catalogue() const { return catalogue_; }

private:
  friend class RuntimeSession;
  using ShapeSymbols = std::unordered_map<std::string, int64_t>;
  struct Binding {
    std::string input;
    std::string output;
    const TypeProto *input_type;
  };
  std::vector<PersistentValue> ValidateInitial(RuntimeValueMap initial) const;

  const ModelProto &model_;
  StructTypeCatalogue catalogue_;
  mutable std::unordered_map<const TypeProto *, RuntimeSequence::Memo<ShapeSymbols>>
      sequence_validation_;
  std::vector<Binding> bindings_;
  std::vector<PersistentValue> values_;
  size_t persistent_tensor_initial_capacity_ = 0;
  bool allocators_captured_ = false;
  RawBufferAllocator *execution_allocator_ = nullptr;
  RawBufferAllocator *io_allocator_ = nullptr;
  mutable std::atomic_flag busy_ = ATOMIC_FLAG_INIT;
};

} // namespace ONNX_LIGHT_NAMESPACE::core::runtime
