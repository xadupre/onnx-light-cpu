// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

/**
 * @file graph_graph.h
 * @brief Graph index and pattern-rewrite driver over a
 *        :cpp:class:`core::builder::GraphBuilder`.
 *
 * :cpp:class:`core::builder::GraphGraph` owns an index over the builder nodes
 * and applies graph-rewrite patterns directly to that builder. It rebuilds its
 * index after every optimization iteration.
 *
 * Nodes are identified by their address, so the index stores
 * ``const NodeProto *`` and maps each to its position in
 * :cpp:func:`GraphBuilder::Nodes` (this mirrors ``make_idn`` / ``id(node)``
 * in Python). The index tracks:
 *
 *   - the producing node of every value (``predecessors``);
 *   - the consuming nodes of every value, deduplicated and in insertion order
 *     (``successors``);
 *   - the declared graph outputs;
 *   - the values captured by a nested subgraph from the enclosing scope, so a
 *     rewrite never deletes a producer a subgraph still relies on.
 *
 * On top of the structural index the class also exposes the read-only value
 * queries a pattern needs -- shapes, element types and constants -- drawing on
 * the builder's inferred information and constant analysis rather than
 * re-implementing them. Constant-folding results are cached by value name
 * because a name is assigned once and never reused.
 */

#pragma once

#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "onnx_core/builder/graph_builder.h"
#include "onnx_core/builder/pattern_optimization.h"
#include "onnx_core/symbolic/sym_tensor.h"
#include "onnx_proto/onnx.h"

namespace ONNX_LIGHT_NAMESPACE::core::builder {

using ::onnx_light::core::symbolic::SymTensor;
using ::onnx_light::core::symbolic::TensorType;

/**
 * Index and rewrite driver over the nodes of a :cpp:class:`GraphBuilder`.
 *
 * The referenced :cpp:class:`GraphBuilder` must outlive this object. Mutating
 * the builder outside :cpp:func:`Optimize` invalidates the index.
 */
class GraphGraph {
public:
  /// Predicate that protects matching nodes from removal.
  using DoNotRemovePredicate = std::function<bool(const NodeProto &)>;

  /// Observes an eligible match and returns whether it may be applied.
  using OptimizationCallback = std::function<bool(const GraphGraph &, const MatchResult &)>;

  /// Builds the index with registered device-independent patterns.
  /// The builder must outlive the index; its device does not change this selection.
  explicit GraphGraph(GraphBuilder &builder);

  /// Builds the index and uses the supplied patterns in their given order.
  GraphGraph(GraphBuilder &builder, std::vector<std::unique_ptr<PatternOptimization>> patterns,
             DoNotRemovePredicate do_not_remove = {});

  /// Builds the index and shares ownership of the supplied patterns.
  GraphGraph(GraphBuilder &builder, std::vector<std::shared_ptr<PatternOptimization>> patterns);

  /// Returns the builder being indexed and optimized.
  GraphBuilder &Builder() noexcept { return builder_; }

  /// Returns the builder for read-only inspection.
  const GraphBuilder &Builder() const noexcept { return builder_; }

  /// Sets a concrete target on this builder, its local functions and their subgraphs.
  /// Rejects conflicting existing devices before modifying any builder.
  void SetTargetDevice(symbolic::Device device);

  /// Establishes canonical value names and export-stable Shape/Size ordering before capture.
  std::size_t Canonicalize();

  /**
   * Applies patterns and cleanup passes until convergence.
   *
   * Patterns are considered in ascending priority order. A negative
   * ``max_iter`` selects ``max(node_count, 10) * priority_count``.
   * Replacement nodes whose inputs are all materialized constants are folded
   * into initializers before cleanup, subject to ``folding_options``.
   * ``remove_unused=false`` disables only unused-node cleanup; other cleanup
   * passes may still remove nodes or initializers.
   * ``parallel=true`` matches candidates concurrently when the pattern's
   * CanMatchInParallel returns true. Python-defined patterns are evaluated
   * sequentially, including in mixed native/Python pattern lists.
   * Concurrent matchers may read the frozen structural index through NodeBefore,
   * NextNodes, Predecessors, Successors, IsOutput, IsUsed, IsUsedMoreThanOnce,
   * IsUsedBySubgraph, and Position. They must not mutate Builder or call
   * SetComputedConstant. Other queries require their own thread-safety audit,
   * including any lazy evaluation or cache writes in their dependencies.
   * ``callback`` observes each eligible, disjoint match before its nodes are
   * reserved, including matches in nested subgraphs. Returning false rejects
   * that match without blocking other patterns. It does not intercept cleanup.
   * The callback must not mutate the graph, patterns, or match, and must not
   * retain references to the graph or matched nodes beyond the call.
   *
   * Returns:
   *   Self-contained records of the applied rewrites, in application order.
   */
  RewritingProto Optimize(int max_iter = -1, OptimizationReport *report = nullptr,
                          const ConstantFoldingOptions &folding_options = {},
                          bool remove_unused = true, const OptimizationCallback &callback = {},
                          bool parallel = false);

  /// Returns the patterns owned by this graph optimizer.
  const std::vector<std::shared_ptr<PatternOptimization>> &Patterns() const noexcept {
    return patterns_;
  }

  /// Returns a function captured before this optimization pass, or nullptr outside a pass.
  /// The definition remains valid only during the current pattern invocation.
  const FunctionProto *FunctionBeforeOptimization(const std::string &domain,
                                                  const std::string &name,
                                                  const std::string &overload = "") const;

  // ── Structural queries ───────────────────────────────────────────────

  /// Returns the node producing ``name``, or ``nullptr`` when ``name`` is a
  /// graph input, an initializer or otherwise not produced by any node.
  const NodeProto *NodeBefore(const std::string &name) const;

  /// Returns the nodes consuming ``name`` (in insertion order, deduplicated).
  /// Returns a reference to a shared empty vector when ``name`` is unused.
  const std::vector<const NodeProto *> &NextNodes(const std::string &name) const;

  /// Returns the nodes producing the inputs of ``node`` (its immediate
  /// predecessors in the data-flow graph), deduplicated and in input order.
  /// Inputs that are graph inputs or initializers contribute no predecessor.
  std::vector<const NodeProto *> Predecessors(const NodeProto &node) const;

  /// Returns the nodes consuming the outputs of ``node`` (its immediate
  /// successors in the data-flow graph), deduplicated and in output order.
  std::vector<const NodeProto *> Successors(const NodeProto &node) const;

  /// Returns ``true`` when ``name`` is a declared graph output.
  bool IsOutput(const std::string &name) const;

  /// Returns ``true`` when ``name`` is consumed by a node, captured by a nested
  /// subgraph, or declared as a graph output.
  bool IsUsed(const std::string &name) const;

  /// Returns ``true`` when ``name`` is consumed by more than one node, captured
  /// by a nested subgraph, or declared as a graph output.
  bool IsUsedMoreThanOnce(const std::string &name) const;

  /// Returns ``true`` when ``name`` is captured by a nested subgraph from the
  /// enclosing scope.
  bool IsUsedBySubgraph(const std::string &name) const;

  /// Returns whether an enclosing operator body has the exact domain and operator type.
  bool IsInsideOperatorBody(const std::string &domain, const std::string &op_type) const;

  /// Returns the position of ``node`` in :cpp:func:`GraphBuilder::Nodes`.
  /// Throws :cpp:class:`BuilderError` when ``node`` is not part of the index.
  std::size_t Position(const NodeProto &node) const;

  // ── Value queries ────────────────────────────────────────────────────

  /// Returns ``true`` when the shape of ``name`` has been inferred.
  bool HasShape(const std::string &name) const;

  /// Returns the inferred descriptor of ``name``. Throws when it is unknown.
  const SymTensor &GetShape(const std::string &name) const;

  /// Returns ``true`` when the element type of ``name`` is known.
  bool HasType(const std::string &name) const;

  /// Returns the element type of ``name``. Throws when it is unknown.
  TensorType GetType(const std::string &name) const;

  /// Returns ``true`` when ``name`` is a constant value (an initializer, a
  /// ``Constant`` output, or the output of a deterministic node whose inputs
  /// are all constant), as tracked by the builder's constant analysis.
  bool IsConstant(const std::string &name) const;

  /// Returns ``true`` when ``name`` is a constant scalar.
  ///
  /// A value is scalar when its shape is ``()`` or ``(1,)``. When ``broadcast``
  /// is ``true`` a shape whose every dimension is ``1`` (e.g. ``(1, 1)``) also
  /// qualifies. This overload does not compare the stored value.
  bool IsConstantScalar(const std::string &name, bool broadcast = false) const;

  /// Returns ``true`` when ``name`` is a constant scalar equal to ``value``.
  ///
  /// The scalar-shape rules of the other overload apply; in addition the stored
  /// value must be readable and compare equal to ``value``.
  bool IsConstantScalar(const std::string &name, double value, bool broadcast) const;

  /// Returns the tensor value of the constant ``name``, or ``nullptr`` when the
  /// value is not materialised as a :cpp:class:`TensorProto` (for example a
  /// ``Constant`` node using ``value_int`` / ``value_float``, or a constant
  /// that has not been folded). Registered computed constants take precedence
  /// over the builder's initializers and ``Constant`` node attributes.
  const TensorProto *GetComputedConstant(const std::string &name) const;

  /// Returns the scope providing a materialized constant, or nullptr when no
  /// visible definition exists. Local definitions never resolve to outer values.
  const GraphGraph *GetConstantScope(const std::string &name) const;

  /// Records a folded constant value for ``name`` so later queries can read it
  /// through :cpp:func:`GetComputedConstant`. A name is assigned once and never
  /// reused, so the cached value stays valid for the lifetime of the index.
  void SetComputedConstant(const std::string &name, TensorProto value);

private:
  using OriginalFunctions = std::unordered_map<std::string, const FunctionProto *>;

  std::size_t CanonicalizeImpl(bool &reference_changed);
  void Rebuild();
  void RebuildSuccessors();
  std::size_t Cleanup(utils::RepeatedProtoField<LocalRewritingProto> &rewrites, bool remove_unused,
                      detail::RewritingUndoState &undo);

  // Returns the concrete dims of the constant ``name`` (empty vector for a
  // scalar) into ``dims``, or ``false`` when the shape cannot be determined.
  bool ConstantShape(const std::string &name, std::vector<int64_t> &dims) const;

  // Reads the scalar value of the constant ``name`` as a double into ``out``,
  // or returns ``false`` when it cannot be read.
  bool ConstantScalarValue(const std::string &name, double &out) const;
  bool IsVisibleBefore(const std::string &name, std::size_t position_limit) const;

  GraphGraph(GraphBuilder &builder,
             const std::vector<std::shared_ptr<PatternOptimization>> &patterns,
             DoNotRemovePredicate do_not_remove, const GraphGraph *parent_graph,
             std::size_t parent_position_limit,
             const OriginalFunctions *original_functions = nullptr);

  RewritingProto OptimizeImpl(int max_iterations, OptimizationReport *report,
                              const std::vector<std::string> &graph_path,
                              const ConstantFoldingOptions &folding_options, bool remove_unused,
                              RewritingProto &collection, detail::RewritingUndoState &undo,
                              const OptimizationCallback &callback, bool parallel);

  GraphBuilder &builder_;
  std::vector<std::shared_ptr<PatternOptimization>> patterns_;
  DoNotRemovePredicate do_not_remove_;
  const GraphGraph *parent_graph_ = nullptr;
  std::size_t parent_position_limit_ = 0;
  const OriginalFunctions *original_functions_ = nullptr;
  // Value name -> producing node (mirrors Python ``predecessors_``).
  std::unordered_map<std::string, const NodeProto *> predecessors_;
  // Value name -> consuming nodes, deduplicated, in insertion order.
  std::unordered_map<std::string, std::vector<const NodeProto *>> successors_;
  // Node address -> position in GraphBuilder::Nodes.
  std::unordered_map<const NodeProto *, std::size_t> positions_;
  // Declared graph output names.
  std::unordered_set<std::string> output_names_;
  // Values captured by a nested subgraph from the enclosing scope.
  std::unordered_set<std::string> subgraph_captured_;
  // Constant initializer name -> tensor; overridable input defaults are excluded.
  std::unordered_map<std::string, const TensorProto *> initializers_;
  // Folded-constant cache keyed by value name.
  std::unordered_map<std::string, TensorProto> computed_constants_;
};

} // namespace ONNX_LIGHT_NAMESPACE::core::builder
