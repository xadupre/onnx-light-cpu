#pragma once
#include "onnx_proto/stream.h"
