// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

// Adapter for all ops that remove consumed_inputs

#pragma once

#include <memory>
#include <string>

#include "onnx_lib/version_converter/adapters/adapter.h"

namespace ONNX_LIGHT_NAMESPACE::version_conversion {

class RemoveConsumedInputs : public Adapter {
public:
  explicit RemoveConsumedInputs(const std::string &op_name, const OpSetID &initial,
                                const OpSetID &target)
      : Adapter(op_name, initial, target) {}

  Node *adapt(std::shared_ptr<Graph> /*unused*/, Node *node) const override {
    if (node->hasAttribute(kconsumed_inputs))
      node->removeAttribute(kconsumed_inputs);
    return node;
  }
};

} // namespace ONNX_LIGHT_NAMESPACE::version_conversion
