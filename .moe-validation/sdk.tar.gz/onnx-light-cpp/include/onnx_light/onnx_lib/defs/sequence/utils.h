// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

/**
 * @file sequence/utils.h
 * @brief Declares reusable schema helpers for sequence operators.
 *
 * This header provides sequence-domain utility generators, including the
 * SplitToSequence schema helper shared by operator definitions.
 */

#pragma once

#include <string>
#include <vector>

#include "onnx_lib/defs/schema.h"
#include "onnx_lib/onnx_pb.h"
#include "onnx_manipulations/tensor_proto_util.h"

namespace ONNX_LIGHT_NAMESPACE::defs::sequence::utils {

std::function<void(OpSchema &)> SplitToSequenceOpGenerator(std::vector<std::string> input_types,
                                                           std::vector<std::string> output_types);

} // namespace ONNX_LIGHT_NAMESPACE::defs::sequence::utils
