// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <string>

#include "onnx_light_helpers.h"

namespace ONNX_LIGHT_NAMESPACE::onnx_op::generator {

/**
 * Returns the documentation string for the Bernoulli operator. The
 * documentation has been stable since opset 15 in the ``ai.onnx`` domain.
 *
 * @return Documentation string for the Bernoulli operator.
 */
std::string MakeBernoulliDoc();

/**
 * Returns the documentation string for the Constant operator at the given
 * opset version.
 *
 * @param since_version Opset version for which to generate the documentation.
 * @return Documentation string for the Constant operator.
 */
std::string MakeConstantDoc(int since_version);

/**
 * Returns the documentation string for the ConstantOfShape operator at the
 * given opset version. The documentation has been stable since opset 9.
 *
 * @param since_version Opset version for which to generate the documentation.
 * @return Documentation string for the ConstantOfShape operator.
 */
std::string MakeConstantOfShapeDoc(int since_version);

/**
 * Returns the documentation string for the EyeLike operator. The
 * documentation has been stable since opset 9.
 *
 * @param since_version Opset version for which to generate the documentation.
 * @return Documentation string for the EyeLike operator.
 */
std::string MakeEyeLikeDoc(int since_version);

/**
 * Returns the documentation string for the RandomNormal operator. The
 * documentation has been stable since opset 1.
 *
 * @return Documentation string for the RandomNormal operator.
 */
std::string MakeRandomNormalDoc();

/**
 * Returns the documentation string for the Multinomial operator. The
 * documentation has been stable since opset 7.
 *
 * @return Documentation string for the Multinomial operator.
 */
std::string MakeMultinomialDoc();

/**
 * Returns the documentation string for the RandomNormalLike operator. The
 * documentation has been stable since opset 1.
 *
 * @return Documentation string for the RandomNormalLike operator.
 */
std::string MakeRandomNormalLikeDoc();

/**
 * Returns the documentation string for the RandomUniform operator. The
 * documentation has been stable since opset 1.
 *
 * @return Documentation string for the RandomUniform operator.
 */
std::string MakeRandomUniformDoc();

/**
 * Returns the documentation string for the RandomUniformLike operator. The
 * documentation has been stable since opset 1.
 *
 * @return Documentation string for the RandomUniformLike operator.
 */
std::string MakeRandomUniformLikeDoc();

/**
 * Returns the documentation string for the Range operator at the given
 * opset version. The documentation was stable from opset 11 through 26;
 * opset 27 appends an explanation of the ``stash_type`` attribute used
 * for ``float16`` and ``bfloat16`` intermediate accumulation.
 *
 * @param since_version Opset version for which to generate the documentation.
 * @return Documentation string for the Range operator.
 */
std::string MakeRangeDoc(int since_version);

} // namespace ONNX_LIGHT_NAMESPACE::onnx_op::generator
