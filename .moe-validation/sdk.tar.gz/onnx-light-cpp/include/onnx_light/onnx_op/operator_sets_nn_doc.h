// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <string>

#include "onnx_light_helpers.h"

namespace ONNX_LIGHT_NAMESPACE::onnx_op::nn {

/**
 * Returns the documentation string for the AveragePool operator at the given
 * opset version.
 *
 * @param since_version Opset version for which to generate the documentation.
 * @return Documentation string for the AveragePool operator.
 */
std::string MakeAveragePoolDoc(int since_version);

/**
 * Returns the documentation string for the MaxPool operator at the given
 * opset version (1, 8, 10, 11, 12, or 22). The text mirrors the upstream
 * ONNX ``PoolOpSchemaGenerator_*`` doc templates with ``name=MaxPool``,
 * ``opName=max`` and the additional max-pool-specific description.
 */
std::string MakeMaxPoolDoc(int since_version);

/**
 * Returns the documentation string for the MaxUnpool operator at the given
 * opset version (9, 11, or 22). The text is identical for every opset and
 * matches the upstream ``kDoc_MaxUnpool_ver11`` string.
 */
std::string MakeMaxUnpoolDoc(int since_version);

/**
 * Returns the documentation string for the MaxRoiPool operator at the given
 * opset version (1 or 22). The text is identical for both opsets and
 * matches the upstream ``RoiPoolOpSchemaGenerator`` template instantiated
 * with ``name="max"``.
 */
std::string MakeMaxRoiPoolDoc(int since_version);

/**
 * Returns the documentation string for the GlobalAveragePool operator at the
 * given opset version (1 or 22).
 */
std::string MakeGlobalAveragePoolDoc(int since_version);

/**
 * Returns the documentation string for the GlobalMaxPool operator at the
 * given opset version (1 or 22).
 */
std::string MakeGlobalMaxPoolDoc(int since_version);

/**
 * Returns the documentation string for the GlobalLpPool operator at the
 * given opset version (1, 2, or 22).
 */
std::string MakeGlobalLpPoolDoc(int since_version);

/**
 * Returns the documentation string for the LpPool operator at the given
 * opset version (1, 2, 11, 18, or 22). The v1 text differs slightly from
 * v2/v11 (v1 has the upstream ``across the / the tensor`` duplication
 * typo), and v18/v22 share a longer text with explicit output-shape
 * formulas.
 */
std::string MakeLpPoolDoc(int since_version);

/**
 * Returns the documentation string for the LRN (Local Response Normalization)
 * operator at the given opset version (1 or 13). The opset 1 text uses bare
 * identifiers while the opset 13 text wraps them in Markdown backticks.
 */
std::string MakeLRNDoc(int since_version);

/**
 * Returns the documentation string for the LpNormalization operator at the
 * given opset version (1 or 22). The text is identical for both opsets and
 * matches the upstream ``kDoc_LpNormalization_ver1`` string.
 */
std::string MakeLpNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the RNN operator at the given opset
 * version (1, 7, 14, or 22).
 */
std::string MakeRNNDoc(int since_version);

/**
 * Returns the documentation string for the GRU operator at the given opset
 * version (1, 3, 7, 14, or 22).
 */
std::string MakeGRUDoc(int since_version);

/**
 * Returns the documentation string for the LSTM operator at the given opset
 * version (1, 7, 14, or 22).
 */
std::string MakeLSTMDoc(int since_version);

/**
 * Returns the documentation string for the BatchNormalization operator at the
 * given opset version (1, 6, 7, 9, 14, or 15).
 */
std::string MakeBatchNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the InstanceNormalization operator at
 * the given opset version (1, 6, or 22). The text is identical for every
 * opset and matches the upstream ``kDoc_InstanceNormalization_ver6`` string.
 */
std::string MakeInstanceNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the GroupNormalization operator at the
 * given opset version (18 or 21).
 */
std::string MakeGroupNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the MeanVarianceNormalization operator
 * at the given opset version (9 or 13).
 */
std::string MakeMeanVarianceNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the Flatten operator at the given
 * opset version (1, 9, 11, 13, 21, 23, 24, or 25). The text is identical for
 * every opset and matches the upstream ``kDoc_Flatten_ver24`` string.
 */
std::string MakeFlattenDoc(int since_version);

/**
 * Returns the documentation string for the Attention operator at the given
 * opset version (23 or 24).
 */
std::string MakeAttentionDoc(int since_version);

/**
 * Returns the documentation string for the RotaryEmbedding operator at the
 * given opset version (23). Mirrors the upstream ``RotaryEmbedding_ver23_doc``
 * string.
 */
std::string MakeRotaryEmbeddingDoc(int since_version);

/**
 * Returns the documentation string for the CausalConvWithState operator at
 * the given opset version (27). Mirrors the upstream
 * ``CausalConvWithState_ver27_doc`` string.
 */
std::string MakeCausalConvWithStateDoc(int since_version);

/**
 * Returns the documentation string for the RMSNormalization operator at the
 * given opset version (23). Mirrors the upstream ``RMSNormalization_ver23_doc``
 * string.
 */
std::string MakeRMSNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the LayerNormalization operator at the
 * given opset version (17). Mirrors the upstream ``LayerNormalization_ver17_doc``
 * string.
 */
std::string MakeLayerNormalizationDoc(int since_version);

/**
 * Returns the documentation string for the DeformConv operator at the given
 * opset version (19 or 22). The text is identical for both opsets and
 * matches the upstream ``kDoc_DeformConv_ver19`` string.
 */
std::string MakeDeformConvDoc(int since_version);

/**
 * Returns the documentation string for the Col2Im operator at the given
 * opset version (18). Matches the upstream ``Col2Im_ver18_doc`` string.
 */
std::string MakeCol2ImDoc(int since_version);

/**
 * Returns the documentation string for the Conv operator at the given opset
 * version (1, 11 or 22). The text is identical for every opset and matches
 * the upstream ``ConvOpSchemaGenerator`` doc string.
 */
std::string MakeConvDoc(int since_version);

/**
 * Returns the documentation string for the ConvInteger operator at opset 10.
 * Matches the upstream ``ConvInteger_ver10_doc`` string.
 */
std::string MakeConvIntegerDoc(int since_version);

/**
 * Returns the documentation string for the ConvTranspose operator at the
 * given opset version (1, 11 or 22). The opset 1 text differs slightly from
 * 11/22 (``auto_pads != SAME_UPPER`` vs ``auto_pads == SAME_UPPER`` in the
 * branch describing the output-shape derivation).
 */
std::string MakeConvTransposeDoc(int since_version);

/**
 * Returns the documentation string for the LinearAttention operator at the
 * given opset version (27). Matches the upstream ``LinearAttention_ver27_doc``
 * string.
 */
std::string MakeLinearAttentionDoc(int since_version);

} // namespace ONNX_LIGHT_NAMESPACE::onnx_op::nn
