#pragma once
#include "onnx_proto/onnx.h"
