#pragma once
#include "onnx_proto/onnx_ort_flatbuffers.h"
