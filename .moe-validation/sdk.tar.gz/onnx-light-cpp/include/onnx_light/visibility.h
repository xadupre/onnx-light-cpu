#pragma once
#include "onnx_proto/visibility.h"
