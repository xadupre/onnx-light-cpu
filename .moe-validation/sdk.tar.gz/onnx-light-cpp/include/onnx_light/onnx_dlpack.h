#pragma once
#include "onnx_proto/onnx_dlpack.h"
