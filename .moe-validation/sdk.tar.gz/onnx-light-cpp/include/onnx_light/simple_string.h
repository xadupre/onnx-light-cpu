#pragma once
#include "onnx_proto/simple_string.h"
