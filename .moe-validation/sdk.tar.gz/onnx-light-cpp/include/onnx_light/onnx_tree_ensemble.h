#pragma once
#include "onnx_proto/onnx_tree_ensemble.h"
