#pragma once
#include "onnx_proto/serialize_options.h"
