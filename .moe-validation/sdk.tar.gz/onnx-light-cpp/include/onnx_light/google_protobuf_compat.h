#pragma once
#include "onnx_proto/google_protobuf_compat.h"
