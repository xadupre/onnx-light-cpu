// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "onnx_core/builder/pattern_optimization.h"

namespace ONNX_LIGHT_NAMESPACE::onnx_patterns {

/**
 * Simplifies ``Gather(Shape(X), indices)`` into ``Shape(X, start, end)`` when
 * ``indices`` is a constant ``int64`` scalar or a contiguous ascending 1-D
 * range.
 *
 * The ``start`` / ``end`` attributes possibly carried by the original ``Shape``
 * node are folded into the new bounds. A scalar index yields a
 * ``Shape`` followed by a ``Squeeze`` of the leading axis to recover the 0-D
 * result.
 *
 * @code
 * Before:
 *          ┌─────────────────────┐
 *   x ────→│ Shape start=1 end=5 │────→ s
 *          └─────────────────────┘
 *                     │
 *                     ↓
 *              ┌──────────────┐
 *              │ Gather axis0 │←──── indices=[1,2]
 *              └──────────────┘
 *                     │
 *                     ↓
 *                     y
 *
 * After:
 *          ┌─────────────────────┐
 *   x ────→│ Shape start=2 end=4 │────→ y
 *          └─────────────────────┘
 *
 * After (scalar index):
 *          ┌─────────────────────┐
 *   x ────→│ Shape start=2 end=3 │────→ s
 *          └─────────────────────┘
 *                    │
 *                    ↓
 *               ┌─────────┐
 *               │ Squeeze │←──── axes=[0]
 *               └─────────┘
 *                    │
 *                    ↓
 *                    y
 * @endcode
 *
 * For scalar index ``1``, the result is
 * ``Squeeze(Shape(x,start=2,end=3),axes=[0])``. If ``s`` has another consumer,
 * the original ``Shape`` is retained.
 */
class GatherShapePattern final : public core::builder::PatternOptimization {
public:
  /// Creates the pattern with the given optimization priority.
  explicit GatherShapePattern(int priority = 0) : PatternOptimization(priority, "GatherShape") {}

  /// Returns ``Gather`` as the only possible root operator.
  std::set<std::string> FastOpType() const override;

  /// Finds a contiguous constant-index ``Gather`` over a ``Shape``.
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;

  /// Rewrites the pair into a bounded ``Shape`` (plus ``Squeeze`` if scalar).
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Replaces ``Shape(Transpose(X, perm))`` by ``Gather(Shape(X), perm)`` so the
 * expensive ``Transpose`` on the full data tensor is avoided.
 *
 * @code
 * Before:
 *          ┌────────────────────────┐
 *   x ────→│ Transpose perm=[2,0,1] │────→ t
 *          └────────────────────────┘
 *                     │
 *                     ↓
 *              ┌─────────────────────┐
 *              │ Shape start=1 end=3 │────→ y
 *              └─────────────────────┘
 *
 * After:
 *          ┌───────┐
 *   x ────→│ Shape │────→ sx
 *          └───────┘
 *              │
 *              ↓
 *        ┌──────────────┐
 *        │ Gather axis0 │←──── indices=[0,1]
 *        └──────────────┘
 *              │
 *              ↓
 *              y
 * @endcode
 *
 * The permutation is a compile-time attribute of the ``Transpose`` node, so the
 * requested dimensions are read directly from ``Shape(X)``. The optional
 * ``start`` / ``end`` attributes of the ``Shape`` node select the sub-range
 * ``perm[start:end]`` used as the ``Gather`` indices. The ``Transpose`` is
 * preserved when its output is consumed elsewhere.
 */
class ShapeTransposePattern final : public core::builder::PatternOptimization {
public:
  /// Creates the pattern with the given optimization priority.
  explicit ShapeTransposePattern(int priority = 0)
      : PatternOptimization(priority, "ShapeTranspose") {}

  /// Returns ``Shape`` as the only possible root operator.
  std::set<std::string> FastOpType() const override;

  /// Finds a ``Shape`` consuming the output of a ``Transpose`` with a perm.
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;

  /// Rewrites the pair into ``Gather(Shape(X), perm)``.
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Removes a ``Cast`` node whose output only feeds ``Shape`` consumers,
 * redirecting each such ``Shape`` node directly to the ``Cast``'s input.
 *
 * ``Shape`` reports the input tensor's dimensions and never depends on its
 * element type, so a ``Cast`` immediately followed only by ``Shape`` nodes can
 * be bypassed without changing any ``Shape`` output, for any opset. Because
 * only the ``Shape`` node's input is rewritten, its ``start`` / ``end``
 * attributes (available since opset 15), name, and metadata are preserved
 * unchanged, and its rank / dimension reporting is unaffected. When the
 * ``Cast`` output is also consumed elsewhere (another op, a graph output, or a
 * subgraph capture), the ``Cast`` is retained for that use and only the
 * matched ``Shape`` node is rewritten; it is dropped once its last ``Shape``
 * consumer has been rewritten.
 *
 * @code
 * Before:
 *            ┌──────┐               ┌─────────────────────┐
 *   x:A ────→│ Cast │────→ c:B ────→│ Shape start=s end=e │────→ y
 *            └──────┘               └─────────────────────┘
 *
 * After:
 *                     ┌─────────────────────┐
 *   x:A ─────────────→│ Shape start=s end=e │────→ y
 *                     └─────────────────────┘
 *
 * After (c:B is also consumed elsewhere):
 *            ┌──────┐
 *   x:A ────→│ Cast │────→ c:B ────→ other consumer
 *            └──────┘
 *
 *                     ┌─────────────────────┐
 *   x:A ─────────────→│ Shape start=s end=e │────→ y
 *                     └─────────────────────┘
 * @endcode
 */
class PreShapeNodeEliminationPattern final : public core::builder::PatternOptimization {
public:
  /// Creates the pattern with the given optimization priority.
  explicit PreShapeNodeEliminationPattern(int priority = 0)
      : PatternOptimization(priority, "PreShapeNodeElimination") {}

  /// Returns ``Cast`` as the only possible root operator.
  std::set<std::string> FastOpType() const override;

  /// Finds a ``Cast`` whose output feeds at least one ``Shape`` node.
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;

  /// Rewrites the matched ``Shape`` node to read directly from the ``Cast``'s
  /// input, keeping the ``Cast`` alive only if still needed elsewhere.
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Replaces ``Shape(Unsqueeze(X, axes))`` by a ``Concat`` of ``Shape(X)`` slices
 * interleaved with constant ``[1]`` tensors at the inserted axis positions.
 *
 * @code
 * Before:
 *   x, axes=[1]
 *        │
 *        ↓
 *   ┌───────────┐
 *   │ Unsqueeze │────→ u
 *   └───────────┘
 *        │
 *        ↓
 *   ┌───────┐
 *   │ Shape │────→ y
 *   └───────┘
 *
 * After:
 *           ┌─────────────────────┐            ┌─────────────────────┐
 *    x ────→│ Shape start=0 end=1 │       [1]  │ Shape start=1 end=3 │←──── x
 *           └─────────────────────┘        │   └─────────────────────┘
 *                      │                   ↓              │
 *                      ↓                                  ↓
 *         ┌────────────────────────────────────────────────────────────┐
 *         │                          Concat                            │────→ y
 *         └────────────────────────────────────────────────────────────┘
 * @endcode
 *
 * ``Shape(Unsqueeze(X, axes))`` equals ``Shape(X)`` with ``1`` entries inserted
 * at the ``axes`` positions, so the (potentially large) ``Unsqueeze`` on the
 * data tensor is avoided entirely while the shape vector stays identical. The
 * ``axes`` input must be a one-dimensional constant and the rank of ``X`` must
 * be known. The optional ``start`` / ``end`` attributes of the ``Shape`` node
 * are honoured. The ``Unsqueeze`` is preserved when its output is consumed
 * elsewhere.
 */
class UnsqueezeShapePattern final : public core::builder::PatternOptimization {
public:
  /// Creates the pattern with the given optimization priority.
  explicit UnsqueezeShapePattern(int priority = 0)
      : PatternOptimization(priority, "UnsqueezeShape") {}

  /// Returns ``Unsqueeze`` as the only possible root operator.
  std::set<std::string> FastOpType() const override;

  /// Finds an ``Unsqueeze`` whose output feeds a ``Shape`` node.
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;

  /// Rewrites the pair into a ``Concat`` of ranged ``Shape`` slices and ``[1]``s.
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

} // namespace ONNX_LIGHT_NAMESPACE::onnx_patterns
