// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "onnx_core/builder/pattern_optimization.h"

namespace ONNX_LIGHT_NAMESPACE::onnx_patterns {

/**
 * Fuses an explicit layer-normalization decomposition.
 *
 * @code
 * Before:
 *    x
 *    │
 *    ├──────────────┐
 *    │              ↓
 *    │        ┌────────────┐
 *    │        │ ReduceMean │────→ mean
 *    │        └────────────┘
 *    ↓              ↓
 *   ┌────────────────┐
 *   │      Sub       │────→ centered
 *   └────────────────┘
 *           │
 *           ├────────────────────────────────────────────┐
 *           │                                            │
 *           │                                            │
 *           ↓                                            │
 *          ┌─────┐                                       │
 *          │ Pow │←──── two                              │
 *          └─────┘                                       │
 *             │ squared                                  │
 *             ↓                                          │
 *            ┌────────────┐                              │
 *            │ ReduceMean │────→ variance                │
 *            └────────────┘                              │
 *                  │                                     │
 *                  │  epsilon                            │
 *                  ↓  │                                  │
 *                 ┌─────┐  ┌──────┐                      │
 *                 │ Add │─→│ Sqrt │────→ deviation       │
 *                 └─────┘  └──────┘                      │
 *                             │                          │
 *                             ↓                          ↓
 *                             └────────────┬─────────────┘
 *                                          ↓
 *                                       ┌─────┐
 *                                       │ Div │────→ y
 *                                       └─────┘
 *
 *   Alternate final path:
 *                 ┌────────────┐
 *    deviation ──→│ Reciprocal │──┐
 *                 └────────────┘  │
 *                                 │ inverse
 *                                 ↓
 *                              ┌─────┐
 *                              │ Mul │────→ y
 *                              └─────┘
 *                                 ↑
 *                                 │
 *                             centered
 *
 * After:
 *          ┌───────┐
 *   x ────→│ Shape │────→ normalized shape
 *          └───────┘
 *
 *                       ┌─────────────────┐
 *   normalized shape ──→│ ConstantOfShape │─────── scale ┐
 *                       ├─────────────────┤              │
 *                       ├─────────────────┤              │
 *   normalized shape ──→│ ConstantOfShape │──────── bias ┤
 *                       └─────────────────┘              │
 *                                                        ↓
 *                                                  ┌────────────────────┐
 *   x ────────────────────────────────────────────→│ LayerNormalization │────→ y
 *                                                  └────────────────────┘
 * @endcode
 *
 * Both means must keep dimensions and reduce the same trailing axes. All
 * removed intermediates must be unshared. Scale and bias are initializers when
 * the final dimension is static; otherwise the shown Shape branches create
 * one and zero tensors.
 */
class LayerNormalizationPattern final : public core::builder::PatternOptimization {
public:
  explicit LayerNormalizationPattern(int priority = 1)
      : PatternOptimization(priority, "LayerNormalization") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Folds a following affine transform into LayerNormalization parameters.
 *
 * @code
 * Before:
 *                      ┌────────────────────┐
 *    x, scale, bias ──→│ LayerNormalization │
 *                      └────────────────────┘
 *                                │
 *                                ↓
 *                             ┌─────┐                ┌─────┐
 *    extra scale ────────────→│ Mul │────→ scaled ──→│ Add │────→ y
 *                             └─────┘                └─────┘
 *                                                       ↑
 *                                                       │
 *                                                  extra bias
 *
 * After:
 *                           ┌─────┐
 *    scale, extra scale ───→│ Mul │──────────────────────────────────────────┐
 *                           └─────┘                                          │
 *                                                                            │ new scale
 *                                                                            │
 *                           ┌─────┐                     ┌─────┐              │
 *    bias, extra scale ────→│ Mul │────→ scaled bias ──→│ Add │              │
 *                           └─────┘                     └─────┘              │
 *                                                         ↑ │                │
 *                                                         │ │                │
 *                                              extra bias   │                │
 *                                                           ↓                ↓
 *                                                           └───────┬────────┘
 *                                                                   ↓
 *                                                    ┌────────────────────┐
 *    x ─────────────────────────────────────────────→│ LayerNormalization │────→ y
 *                                                    └────────────────────┘
 * @endcode
 *
 * The extra scale, optional bias, and original scale must have equal shapes.
 * The normalization and Mul outputs must not have unrelated consumers.
 * Parameter Mul or Add nodes are omitted when an existing unit scale or a
 * missing bias makes them unnecessary.
 */
class LayerNormalizationScalePattern final : public core::builder::PatternOptimization {
public:
  explicit LayerNormalizationScalePattern(int priority = 1)
      : PatternOptimization(priority, "LayerNormalizationScale") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Removes FP32 promotion around eligible standard FP16 normalization.
 *
 * @code
 * Before:
 *          ┌──────┐                    ┌───────────────┐       ┌──────┐
 *   x ────→│ Cast │────→ promoted ────→│ Normalization │──────→│ Cast │────→ y
 *          └──────┘                    └───────────────┘       └──────┘
 *                                          ↑
 *                                          │
 *                                    unit scale (FP32)
 *
 * After:
 *                       ┌──────┐
 *    unit scale ───────→│ Cast │
 *                       └──────┘
 *                           │ converted parameters
 *                           ↓
 *                        ┌───────────────┐
 *    x ─────────────────→│ Normalization │────→ y
 *                        └───────────────┘
 * @endcode
 *
 * Supports only standard LayerNormalization (opset 17+) and RMSNormalization
 * (opset 23+), with FLOAT stash_type, constant unit scale and no bias (an empty
 * optional bias is allowed). Both schemas round normalized values to the I/O
 * type before the affine stage, so even FP16-representable arbitrary weights
 * are unsafe. Bias is conservatively rejected, including zero bias, to preserve
 * signed-zero rounding. FP32 unit weights are converted exactly; existing
 * FP16-to-FP32 scale casts are bypassed. Saved statistics retain their FP32
 * computation and names, including live outputs. The FP32 data output must be
 * exclusive to the output Cast; shared upstream casts are preserved.
 */
class CastLayerNormalizationCastPattern final : public core::builder::PatternOptimization {
public:
  explicit CastLayerNormalizationCastPattern(int priority = 1)
      : PatternOptimization(priority, "CastLayerNormalizationCast") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Removes an identity BatchNormalization in inference mode.
 *
 * @code
 * Before:
 *                                        ┌────────────────────┐
 *   x, scale, bias, mean, variance ─────→│ BatchNormalization │────→ y
 *                                        └────────────────────┘
 *
 * After:
 *          ┌──────────┐
 *   x ────→│ Identity │────→ y
 *          └──────────┘
 * @endcode
 *
 * Scale and variance must be constant ones; bias and mean must be constant
 * zeros. Epsilon is zero, training mode is disabled, and running-statistic
 * outputs must be unused.
 */
class BatchNormalizationPattern final : public core::builder::PatternOptimization {
public:
  explicit BatchNormalizationPattern(int priority = 0)
      : PatternOptimization(priority, "BatchNormalization") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Expands training BatchNormalization into primitive operators.
 *
 * @code
 * Before:
 *                                                    ┌────────────────────┐
 *   x, scale, bias, running mean, running variance ─→│ BatchNormalization │────→ y
 *                                                    └────────────────────┘
 *
 * After:
 *    x
 *    │
 *    ├──────────────┐
 *    │              ↓
 *    │        ┌────────────┐
 *    │        │ ReduceMean │────→ mean
 *    │        └────────────┘
 *    ↓              ↓
 *   ┌────────────────┐
 *   │      Sub       │────→ centered
 *   └────────────────┘
 *           │
 *           ├──────────────────────────────────────────────────────┐
 *           │                                                      │
 *         ┌─┴─┐                                                    │
 *         │   │                                                    │
 *         ↓   ↓                                                    │
 *         ┌───┐                                                    │
 *         │Mul│                                                    │
 *         └───┘                                                    │
 *           │                                                      │
 *           ↓                                                      │
 *          ┌────────────┐                                          │
 *          │ ReduceMean │────→ variance                            │
 *          └────────────┘                                          │
 *                │                                                 │
 *                │  epsilon                                        │
 *                ↓  │                                              │
 *               ┌─────┐  ┌──────┐                                  │
 *               │ Add │─→│ Sqrt │────→ deviation                   │
 *               └─────┘  └──────┘                                  │
 *                  ↑                                               │
 *                  │                                               │
 *              variance                                            │
 *                           │                                      │
 *                           ↓                                      ↓
 *                           └──────────────────┬───────────────────┘
 *                                              ↓
 *                                           ┌─────┐
 *                                           │ Div │────→ normalized
 *                                           └─────┘
 *                                                 │
 *                                                 │
 *             ┌─────────┐                         │
 *    scale ──→│ Reshape │──┐                      │
 *             └─────────┘  │                      │
 *                          │ broadcast scale      │
 *                          ↓                      ↓
 *                          └──────────┬───────────┘
 *                                     ↓
 *                                  ┌─────┐
 *                                  │ Mul │────→ scaled
 *                                  └─────┘
 *                                     │ scaled
 *                                     └──────────────────┐
 *                                                        │
 *             ┌─────────┐                                │
 *    bias ───→│ Reshape │──┐                             │
 *             └─────────┘  │                             │
 *                          │ broadcast bias              │
 *                          ↓                             ↓
 *                          └──────────────┬──────────────┘
 *                                         ↓
 *                                      ┌─────┐
 *                                      │ Add │────→ y
 *                                      └─────┘
 * @endcode
 *
 * The rewrite requires opset 18, a known input rank of at least two, known
 * scale and bias ranks, and unused running-statistic outputs. Both ReduceMean
 * nodes reduce every axis except channel axis 1. Reshape is emitted only for
 * rank-one scale or bias inputs.
 */
class BatchNormalizationTrainingPattern final : public core::builder::PatternOptimization {
public:
  explicit BatchNormalizationTrainingPattern(int priority = 0)
      : PatternOptimization(priority, "BatchNormalizationTraining") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Fuses an explicit root-mean-square normalization decomposition.
 *
 * @code
 * Before:
 *   Optional input conversion:
 *          ┌──────┐
 *   x ────→│ Cast │────→ z
 *          └──────┘
 *
 *    z
 *    │
 *    ├────────────────────────────────────────────┐
 *    │                                            │
 *    │                                            │
 *    ↓                                            │
 *   ┌─────┐                                       │
 *   │ Pow │←──── two                              │
 *   └─────┘                                       │
 *      │ squared                                  │
 *      ↓                                          │
 *     ┌────────────┐                              │
 *     │ ReduceMean │────→ mean square             │
 *     └────────────┘                              │
 *           │                                     │
 *           │  epsilon                            │
 *           ↓  │                                  │
 *          ┌─────┐  ┌──────┐                      │
 *          │ Add │─→│ Sqrt │────→ deviation       │
 *          └─────┘  └──────┘                      │
 *                      │                          │
 *                      ↓                          │
 *                ┌────────────┐                   │
 *                │ Reciprocal │────→ inverse      │
 *                └────────────┘                   │
 *                                │                │
 *                                ↓                ↓
 *                                └───────┬────────┘
 *                                        ↓
 *                                     ┌─────┐
 *                                     │ Mul │────→ normalized
 *                                     └─────┘
 *
 *   Alternate inverse path:
 *                      ┌─────┐
 *   one, deviation ───→│ Div │────→ inverse
 *                      └─────┘
 *
 *   Optional output conversion:
 *                ┌──────┐
 *   normalized ─→│ Cast │────→ y
 *                └──────┘
 *
 * After:
 *          ┌───────┐       ┌─────────────────┐
 *   x ────→│ Shape │──────→│ ConstantOfShape │────→ scale
 *          └───────┘       └─────────────────┘
 *
 *               ┌──────────────────┐
 *   x, scale ──→│ RMSNormalization │────→ y
 *               └──────────────────┘
 * @endcode
 *
 * The optional Cast pair must convert to the reduction stash type and restore
 * the original type. The rewrite requires opset 23, suffix reduction axes,
 * and unshared intermediates. The scale is a static initializer when its shape
 * is known; otherwise the shown Shape branch creates an all-ones tensor.
 */
class RMSNormalizationPattern final : public core::builder::PatternOptimization {
public:
  explicit RMSNormalizationPattern(int priority = 1)
      : PatternOptimization(priority, "RMSNormalization") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

/**
 * Folds a constant post-scale into RMSNormalization.
 *
 * @code
 * Before:
 *                 ┌──────────────────┐
 *    x, scale1 ──→│ RMSNormalization │
 *                 └──────────────────┘
 *                           │
 *                           ↓
 *                       ┌─────┐
 *    scale2 ───────────→│ Mul │────→ y
 *                       └─────┘
 *
 * After:
 *                       ┌──────────────────┐
 *   x, combined scale ─→│ RMSNormalization │────→ y
 *                       └──────────────────┘
 * @endcode
 *
 * Both scales must be constants with identical shapes and a representable
 * elementwise product. The RMSNormalization output must be unshared.
 */
class RMSNormalizationMulPattern final : public core::builder::PatternOptimization {
public:
  explicit RMSNormalizationMulPattern(int priority = 1)
      : PatternOptimization(priority, "RMSNormalizationMul") {}

  std::set<std::string> FastOpType() const override;
  core::builder::MatchResult Match(core::builder::GraphGraph &graph,
                                   const NodeProto &candidate) const override;
  utils::RepeatedProtoField<NodeProto>
  Apply(core::builder::GraphGraph &graph,
        const std::vector<const NodeProto *> &nodes) const override;
};

} // namespace ONNX_LIGHT_NAMESPACE::onnx_patterns
