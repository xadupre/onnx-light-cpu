#pragma once
#include "onnx_proto/stream_class_adapters.hpp"
