#pragma once
#include "onnx_proto/blake3/blake3.h"
