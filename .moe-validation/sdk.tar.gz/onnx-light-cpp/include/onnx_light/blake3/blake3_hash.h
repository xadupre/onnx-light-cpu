#pragma once
#include "onnx_proto/blake3/blake3_hash.h"
