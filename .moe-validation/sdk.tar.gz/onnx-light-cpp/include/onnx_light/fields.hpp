#pragma once
#include "onnx_proto/fields.hpp"
