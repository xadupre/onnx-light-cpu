#pragma once
#include "onnx_proto/fields.h"
