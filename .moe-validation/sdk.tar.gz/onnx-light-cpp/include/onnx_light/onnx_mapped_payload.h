#pragma once
#include "onnx_proto/onnx_mapped_payload.h"
