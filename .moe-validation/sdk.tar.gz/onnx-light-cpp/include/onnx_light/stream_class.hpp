#pragma once
#include "onnx_proto/stream_class.hpp"
