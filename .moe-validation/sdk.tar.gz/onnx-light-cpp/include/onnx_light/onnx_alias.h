#pragma once
#include "onnx_proto/onnx_alias.h"
