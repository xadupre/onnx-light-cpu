#pragma once
#include "onnx_proto/stream_class_print.hpp"
