#pragma once
#include "onnx_proto/type_helper.h"
