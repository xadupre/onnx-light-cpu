#pragma once
#include "onnx_proto/onnx_io_policy.h"
