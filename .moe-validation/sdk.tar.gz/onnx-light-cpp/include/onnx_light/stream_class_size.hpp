#pragma once
#include "onnx_proto/stream_class_size.hpp"
