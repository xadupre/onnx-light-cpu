#pragma once
#include "onnx_proto/dlpack/dlpack.h"
