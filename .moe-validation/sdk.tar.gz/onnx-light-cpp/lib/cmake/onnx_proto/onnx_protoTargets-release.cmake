#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "onnx_proto::lib_onnx_proto" for configuration "Release"
set_property(TARGET onnx_proto::lib_onnx_proto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_proto::lib_onnx_proto PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_proto.a"
  )

list(APPEND _cmake_import_check_targets onnx_proto::lib_onnx_proto )
list(APPEND _cmake_import_check_files_for_onnx_proto::lib_onnx_proto "${_IMPORT_PREFIX}/lib/liblib_onnx_proto.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
