#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "onnx_light::lib_onnx_core" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_core.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_core )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_core "${_IMPORT_PREFIX}/lib/liblib_onnx_core.a" )

# Import target "onnx_light::lib_onnx_manipulations" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_manipulations APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_manipulations PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_manipulations.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_manipulations )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_manipulations "${_IMPORT_PREFIX}/lib/liblib_onnx_manipulations.a" )

# Import target "onnx_light::lib_onnx_lib" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_lib PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_lib.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_lib )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_lib "${_IMPORT_PREFIX}/lib/liblib_onnx_lib.a" )

# Import target "onnx_light::lib_onnx_op" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_op APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_op PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_op.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_op )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_op "${_IMPORT_PREFIX}/lib/liblib_onnx_op.a" )

# Import target "onnx_light::lib_onnx_shape" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_shape APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_shape PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_shape.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_shape )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_shape "${_IMPORT_PREFIX}/lib/liblib_onnx_shape.a" )

# Import target "onnx_light::lib_onnx_patterns" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_patterns APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_patterns PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_patterns.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_patterns )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_patterns "${_IMPORT_PREFIX}/lib/liblib_onnx_patterns.a" )

# Import target "onnx_light::lib_onnx_kernels" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_kernels APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_kernels PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_kernels.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_kernels )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_kernels "${_IMPORT_PREFIX}/lib/liblib_onnx_kernels.a" )

# Import target "onnx_light::lib_onnx_backend_test" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_backend_test APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_backend_test PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_backend_test.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_backend_test )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_backend_test "${_IMPORT_PREFIX}/lib/liblib_onnx_backend_test.a" )

# Import target "onnx_light::lib_onnx_gradient" for configuration "Release"
set_property(TARGET onnx_light::lib_onnx_gradient APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_light::lib_onnx_gradient PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_gradient.a"
  )

list(APPEND _cmake_import_check_targets onnx_light::lib_onnx_gradient )
list(APPEND _cmake_import_check_files_for_onnx_light::lib_onnx_gradient "${_IMPORT_PREFIX}/lib/liblib_onnx_gradient.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
