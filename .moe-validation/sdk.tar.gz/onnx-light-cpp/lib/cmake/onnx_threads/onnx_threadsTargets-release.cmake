#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "onnx_threads::lib_onnx_threads" for configuration "Release"
set_property(TARGET onnx_threads::lib_onnx_threads APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(onnx_threads::lib_onnx_threads PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liblib_onnx_threads.a"
  )

list(APPEND _cmake_import_check_targets onnx_threads::lib_onnx_threads )
list(APPEND _cmake_import_check_files_for_onnx_threads::lib_onnx_threads "${_IMPORT_PREFIX}/lib/liblib_onnx_threads.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
