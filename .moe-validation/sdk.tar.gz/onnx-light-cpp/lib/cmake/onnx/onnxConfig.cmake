
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was onnxConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
get_filename_component(_onnx_cmake_root "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)

find_dependency(onnx_light CONFIG REQUIRED
  PATHS "${_onnx_cmake_root}/onnx_light"
  NO_DEFAULT_PATH
)

# The drop-in `onnx/*.h` / `google/protobuf/*.h` forwarding headers live
# alongside the onnx_light headers (installed by CMakeLists.txt's
# `install(DIRECTORY .../onnx_compat_include/ DESTINATION
# .../onnx_light/onnx_compat_include)` rule). Linking against
# onnx_light::lib_onnx_lib etc. alone only propagates the
# include/onnx_light include dir, NOT this compat dir, so it must be added
# explicitly here or downstream code including "onnx/defs/schema.h" and
# friends fails with "No such file or directory".
set(_onnx_compat_include_dir "${PACKAGE_PREFIX_DIR}/include/onnx_light/onnx_compat_include")

# Aggregate the onnx-light libraries that together provide the upstream-onnx
# C++ API surface (message types, operator schemas, checker and shape
# inference) behind a single drop-in `onnx::onnx` target.
if(NOT TARGET onnx::onnx)
  add_library(onnx::onnx INTERFACE IMPORTED)
  set_target_properties(onnx::onnx PROPERTIES
    INTERFACE_LINK_LIBRARIES
      "onnx_light::lib_onnx_lib;onnx_light::lib_onnx_op;onnx_light::lib_onnx_shape;onnx_light::lib_onnx_manipulations;onnx_proto::lib_onnx_proto"
    INTERFACE_INCLUDE_DIRECTORIES "${_onnx_compat_include_dir}"
  )
endif()

# `onnx::onnx_proto` maps to the protobuf-compatible message library.
if(NOT TARGET onnx::onnx_proto)
  add_library(onnx::onnx_proto INTERFACE IMPORTED)
  set_target_properties(onnx::onnx_proto PROPERTIES
    INTERFACE_LINK_LIBRARIES onnx_proto::lib_onnx_proto
    INTERFACE_INCLUDE_DIRECTORIES "${_onnx_compat_include_dir}"
  )
endif()

check_required_components(onnx)
